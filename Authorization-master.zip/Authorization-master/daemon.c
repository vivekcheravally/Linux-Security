#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>

#define MIN 100000
#define MAX 1000000

extern int errno;
char path[256];
mode_t mode;
char mode1[256];
char perm[256];
char getperm[256];
int oflag;
FILE *fp1;
FILE *fp2;
static const char * const SOCKET_PATH = "my_path";

int getrand(int min,int max)
{
	return(rand()%(max-min)+min);
}

int min(char a, char b)
{
    if(a<b)	
        return a;
    else	
		return b;  	  
}

int getid(int connection_fd,uid_t euid,gid_t gid)
{
    struct ucred cred;
    socklen_t len=sizeof(cred);
    if(getsockopt(connection_fd,SOL_SOCKET,SO_PEERCRED,&cred,&len)<0)
        return(-1);

    euid=cred.uid;
    gid=cred.gid;
    printf("User id is : %d\n", euid);
    printf("Group id is : %d\n", gid);
    fp1 = fopen ("mydaemonfile.txt", "a");
    fprintf(fp1,"User id is :%d\n", euid);
    fprintf(fp1,"Group id is :%d\n", gid);
    fclose(fp1);
    return 0;
}

static int create_server()
{
 	int socket_fd = -1;
    struct sockaddr_un address;

    socket_fd = socket(PF_UNIX, SOCK_STREAM, 0);
    if (socket_fd < 0)
    {
        printf("socket() failed\n");
        goto EXIT;
    }

    unlink(SOCKET_PATH);
    /* start with a clean address structure */
    bzero(&address,sizeof(address));
    address.sun_family = AF_UNIX;
    strcpy(address.sun_path, SOCKET_PATH);

    if (bind(socket_fd, (struct sockaddr *)&address, sizeof(address)) < 0)
    {
        printf("bind() failed\n");
        goto ERR_BIND;
    }

    if (listen(socket_fd, 5) < 0)
    {
        printf("listen() failed\n");
        goto ERR_LISTEN;
    }

    goto EXIT;
	    ERR_LISTEN:
	       ERR_BIND:
            close(socket_fd);
  	      socket_fd = -1;
	  EXIT:
      return socket_fd;
}

int connection_handler(int connection_fd)
{
    int nbytes;
 	char buffer[256];

 	nbytes = read(connection_fd, buffer, 256);
 	buffer[nbytes] = 0;
 	strcpy(path,buffer);
 	printf("FIRST MESSAGE FROM CLIENT: %s\n", path);

        nbytes = snprintf(buffer, 256, "CapD : Got the path....waiting for file flag");
        write(connection_fd, buffer, nbytes);

 	nbytes = read(connection_fd, buffer, 256);
  	buffer[nbytes] = 0;
    oflag=atoi(buffer);
  	printf("SECOND MESSAGE FROM CLIENT: %d\n", oflag);


        nbytes = snprintf(buffer, 256, "CapD : Got the flag....waiting for mode");
        write(connection_fd, buffer, nbytes);

 	nbytes = read(connection_fd, buffer, 256);
  	buffer[nbytes] = 0;
    mode=atoi(buffer);
  	printf("THIRD MESSAGE FROM CLIENT: %o\n", mode);
  	//snprintf(mode1,10,"%d",mode);

        nbytes = snprintf(buffer, 256, "CapD : Got the mode....waiting for operation permissions");
        write(connection_fd, buffer, nbytes);

    nbytes = read(connection_fd, buffer, 256);
    buffer[nbytes] = 0;
    strcpy(perm,buffer);
    printf("FOURTH MESSAGE FROM CLIENT: %s\n", perm);

      fp1=fopen("mydaemonfile.txt","a");
 	  fprintf(fp1,"MESSAGE (PATH) FROM CLIENT: %s\n", path);
 	  fprintf(fp1,"MESSAGE (FLAG) FROM CLIENT: %d\n", oflag);
 	  fprintf(fp1,"MESSAGE (MODE) FROM CLIENT: %o\n", mode);
      fprintf(fp1,"MESSAGE (PERMISSION) FROM CLIENT: %s\n", perm);
 	  fclose(fp1);
	  // close(connection_fd);
 	  return 0;
}

/* Send File Descriptor */

static int send_file_descriptor(int socket_fd, int fd[1])
{
    struct msghdr message;						/*Structure which holds all the information on what to send and recieve*/
    struct iovec iov;							/*Structure holding the I/O buffers*/
    struct cmsghdr *control_message = NULL;		/*control message header*/

 	  char ctrl_buf[CMSG_SPACE(sizeof(int))];
    char data[1];

    memset(&message, 0, sizeof(message));
    memset(&iov, 0, sizeof(iov));
    memset(ctrl_buf, 0, sizeof(ctrl_buf));
    data[0] = '\0';
    iov.iov_base = data;
    iov.iov_len = sizeof(data);

    message.msg_name = NULL;						//optional address
    message.msg_namelen = 0;						//address size in bytes
    message.msg_iov = &iov;							//array of I/O buffers
    message.msg_iovlen = 1;							//number of elements in array
    message.msg_controllen = sizeof(ctrl_buf);		//number of ancillary data
    message.msg_control = ctrl_buf;					//ancillary data

    control_message = CMSG_FIRSTHDR(&message);
    int i = 0;
    //for (i = 0; i < 1; i++)
    //{
    control_message->cmsg_level = SOL_SOCKET;				//orginating protocol
    control_message->cmsg_type = SCM_RIGHTS;				//protocol-specefic type ; SCM-Socket-level control message
    control_message->cmsg_len = CMSG_LEN(sizeof(fd[i]));	//data byte count, including header

    int* dataBuff = ((int*)CMSG_DATA(control_message));		//Macro to obtain the pointer to the integer
    memcpy(dataBuff, fd, sizeof(int));
    control_message = CMSG_NXTHDR(&message, control_message);
 // }

    return sendmsg(socket_fd, &message, 0);
}


/* end code */

/*daemon function */

int daemo()
{
    pid_t pid = 0;
    pid_t sid = 0;

    int i = 0;
    pid = fork();				// fork a new child process

    if (pid < 0)
    {
        printf("fork failed!\n");
        exit(1);
    }

    if (pid > 0)				// its the parent process
    {
        printf("pid of child process %d \n", pid);
        exit(0); 				//terminate the parent process succesfully
    }

    umask(0);					//unmasking the file mode

    sid = setsid();				//set new session
    if(sid < 0)
    {
        exit(1);
    }

    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);

    fp1 = fopen ("mydaemonfile.txt", "a");
    fprintf(fp1,"%s\n", "logging details");
    fclose(fp1);
    return 0;
}

/*end */

/*fstat function*/

int temp(const char *path)
{
	struct stat filestat;
	if(stat(path,&filestat)<0)
		return 1;
	strcpy(getperm,"");

	//FILE *fp;
	//fp=fopen("data.txt","a");
	//fprintf(fp,"File size \t File inode \t File Permissions \n");
	/*fprintf(fp,"%ldbytes\t %lu\t", filestat.st_size,filestat.st_ino);
	fprintf(fp,(S_ISDIR(filestat.st_mode)) ? "d" : "-");
	fprintf(fp,(filestat.st_mode & S_IRUSR) ? "r" : "-");
	fprintf(fp,(filestat.st_mode & S_IWUSR) ? "w" : "-");
	fprintf(fp,(filestat.st_mode & S_IXUSR) ? "x" : "-");
	fprintf(fp,(filestat.st_mode & S_IRGRP) ? "r" : "-");
	fprintf(fp,(filestat.st_mode & S_IWGRP) ? "w" : "-");
	fprintf(fp,(filestat.st_mode & S_IXGRP) ? "x" : "-");
	fprintf(fp,(filestat.st_mode & S_IROTH) ? "r" : "-");
	fprintf(fp,(filestat.st_mode & S_IWOTH) ? "w" : "-");
	fprintf(fp,(filestat.st_mode & S_IXOTH) ? "x" : "-");
	fprintf(fp,"\t\n");
	fclose(fp);*/
	/*printf("File size: \t File inode: \t File Permissions: \n");*/
	//printf("%ldbytes\t %lu\t", filestat.st_size,filestat.st_ino);
	printf((S_ISDIR(filestat.st_mode)) ? "d" : "-");
	strcat(getperm,(S_ISDIR(filestat.st_mode)) ? "d" : "-");
	printf((filestat.st_mode & S_IRUSR) ? "r" : "-");
	strcat(getperm,(filestat.st_mode & S_IRUSR) ? "r" : "-");
	printf((filestat.st_mode & S_IWUSR) ? "w" : "-");
	strcat(getperm,(filestat.st_mode & S_IWUSR) ? "w" : "-");
	printf((filestat.st_mode & S_IXUSR) ? "x" : "-");
	strcat(getperm,(filestat.st_mode & S_IXUSR) ? "x" : "-");
	printf((filestat.st_mode & S_IRGRP) ? "r" : "-");
	strcat(getperm,(filestat.st_mode & S_IRGRP) ? "r" : "-");
	printf((filestat.st_mode & S_IWGRP) ? "w" : "-");
	strcat(getperm,(filestat.st_mode & S_IWGRP) ? "w" : "-");
	printf((filestat.st_mode & S_IXGRP) ? "x" : "-");
	strcat(getperm,(filestat.st_mode & S_IXGRP) ? "x" : "-");
	printf((filestat.st_mode & S_IROTH) ? "r" : "-");
	strcat(getperm,(filestat.st_mode & S_IROTH) ? "r" : "-");
	printf((filestat.st_mode & S_IWOTH) ? "w" : "-");
	strcat(getperm,(filestat.st_mode & S_IWOTH) ? "w" : "-");
	printf((filestat.st_mode & S_IXOTH) ? "x" : "-");
	strcat(getperm,(filestat.st_mode & S_IXOTH) ? "x" : "-");
	printf("\n");
	printf("fstat: Permission bits of %s is %s\n", path,getperm);
}

/*end of fstat*/


/*Main Function */

int main()
{
   // daemo();
	int len,len1,j,random=0;
	char new[10];
    uid_t euid;
    gid_t gid;
    FILE *fp = NULL;
    int fd[1] = {-1};
    int server = -1, client = -1,connection_fd;
    server = create_server();
    if (server < 0)
    {
        printf("create_server() failed\n");
        return 0;
        //goto ERR_CREATE_SERVER;
    }

    while(1)
    {
        client = accept(server, NULL, NULL);
        printf("client() accept %d\n", client);

        fp1=fopen("mydaemonfile.txt","a");
        fprintf(fp1, "client() accept %d\n", client);
        fclose(fp1);

        if (client < 0)
        {
            printf("accept() failed\n");
            goto ERR_ACCEPT;
        }

        printf("give client = %d\n", client);
        getid(client,geteuid(),getgid());
        connection_handler(client);

        /*new code authorization*/
        temp(path);
        fp1=fopen("mydaemonfile.txt","a");
        fprintf(fp1, "FSTAT: PERMISSION OBTAINED FROM FSTAT: %s\n", getperm);
        fclose(fp1);

        len=strlen(perm);
        len1=strlen(getperm);
        //printf("%d\t%d\n", len,len1);
        if(len==len1)
        {
        	for(j=0;j<len;j++)
        	{
        		new[j]=min(getperm[j],perm[j]);
        		//printf("%d\n", new[j]);
        	}
        	printf("Creating Global Capability Objects: %s\n", new);
        	fp1=fopen("mydaemonfile.txt","a");
        	fprintf(fp1, "Creating Capability permissions for Global Capability Objects: %s\n\n", new);
        	fclose(fp1);
        }
        else
        {
        	printf("Object Cannot be created\n");
        }
        
        srand(time(NULL));
        random=getrand(MIN,MAX);
  		printf("UUID Generated for the Capability Object %s is : %d\n", new,random);
        	
        /*end of code */



        fd[0]=open(path,oflag,mode);

        printf("File descriptir is : %d\n", fd[0]);
        if (send_file_descriptor(client, fd) < 0)
        {
            printf("send_file_descriptor failed: %d\n", send_file_descriptor(client, fd));
            perror("sendmsg():");
            goto ERR_SEND_FILE_DESCRIPTOR;
        }

  	    close(client);
    }
	//ERR_SHUTDOWN:
	  ERR_SEND_FILE_DESCRIPTOR:
  	   close(client);
	  ERR_ACCEPT:
  	   close(server);
	  //ERR_CREATE_SERVER:
  	   //fclose(fp);
	  //ERR_FOPEN:
  	   //return 0;
}
